RANDOM_STATE = 42
TRAINING_DATA_FILENAME = 'training_data.xlsx'
RANDOM_FOREST_MODEL_FILENAME = 'random-forest-model.sav'
LOGISTIC_REGRESSION_MODEL_FILENAME = 'logistic-regression-model.sav'
NAIVE_BAYES_MODEL_FILENAME = 'naive-bayes-model.sav'
MODEL_FILENAME = 'model.sav'